const taskBuilder = require('../controllers/taskController');
var VerifyTokens = require('../config/auth')

module.exports = app => {

  app
    .route('/login')
    .post(taskBuilder.loginUser);

  app
    .route('/register')
    .post(taskBuilder.registerNewUser);

  app
    .route('/taluka/editCitizen')
    .post(VerifyTokens,taskBuilder.update_a_citizenProfile);

  app
    .route('/citizen/:citizenId')
    .get(VerifyTokens,taskBuilder.read_a_citizen);

  app
    .route('/search/:id')
    .get(VerifyTokens,taskBuilder.search_Citizen);

  app
     .route('/searchByName/:id')
     .get(VerifyTokens,taskBuilder.search_Citizen_By_Name);

  app
     .route('/searchBySurveyorId/:id')
     .get(VerifyTokens,taskBuilder.search_Citizen_By_SurveyorId);

  app
    .route('/subAdmin/modify/:subAdminId')
    .get(VerifyTokens,VerifyTokens,taskBuilder.read_a_subAdmin);

  app
    .route('/surveyor/:id')
    .get(VerifyTokens,taskBuilder.read_a_surveyor);

  app
    .route('/offlineData')
    .post(VerifyTokens,taskBuilder.create_offline_entry);


};