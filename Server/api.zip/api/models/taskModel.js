const mongoose = require('mongoose');
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { Schema } = mongoose;

const adminSchema = new Schema(
  {
    uniqueCode: {
        type: Number,
        required: 'UniqueID cannot be blank'
    },
    taluka: {
      type: String,
      required: 'taluka cannot be blank'
    },
    name: {
         type: String,
         required: 'ruralUrban cannot be blank'
    },
    phoneNumber: {
        type: String,
        required: 'post cannot be blank'
    },
    username: {
      type: String,
      required: 'username  cannot be blank'
    },
    password: {
      type: String,
      required: [true, "Please Include your password"]
    },
    type: {
        type: String,
    },
    token: {
        type: String,
        required:''
    }
  },
  { collection: 'dataEntry' }
);

const citizenDataSchema = new Schema(
    {
        id: {type: Number, required: true},
        famMapPhoneNumber: {type: String},
        famMapAadhaarNumber: {type: String},
        familyId: {type: String},
        fullName: {type: String, required: true},
        fathersName: {type: String, required: true},
        mothersName: {type: String, required: true},
        gender: {type: String, required: true},
        maritalStatus: {type: String, required: true},
        motherTongue: {type: String, required: true},
        pHandicap: {type: String, required: true},
        religion: {type: String, required: true},
        category: {type: String, required: true},
        caste: {type: String, required: true},
        education: {type: String, required: true},
        occupation: {type: String, required: true},
        accountNumber: {type: String},
        ifscCode: {type: String},
        bankName: {type: String},
        rationCardNumber: {type: String},
        incomeLevel: {type: String, required: true},
        phoneNumber: {type: String},
        houseType: {type: String, required: true},
        houseStatus: {type: String, required: true},
        addressDetails: {type: String, required: true},
        taluka: {type: String, required: true},
        post: {type: String, required: true},
        gramPanchayat: {type: String, required: true},
        village: {type: String, required: true},
        pincode: {type: String, required: true},
        permanentAddress: {type: String},
        permanentDistrict: {type: String},
        permanentState: {type: String},
        permanentPinCode: {type: String},
        uploaded: {type: Number, required: 'uploaded  cannot be blank'},
        viewed: {type: Number},
        reverted: {type: Number},
        deadOrAlive: {type: String},
        dateOfDeath: {type: String},
        schemes: [
            /*{
                schemeID:  {
                    schemeID: {
                        type: String
                    },
                    schemeName: {
                        type: String
                    },
                    department: {
                        type: String
                    },
                    schemeType: {
                        type: String
                    },
                    date: {
                        type: String
                    }
                }
            }*/
        ]
    },
    { collection: 'citizen' }
);

const offlineDataSchema = new Schema(
    {
        id: {type: Number, required: true},
        type: {type: String, required: true},
        remark1: {type: String},
        landClass: {type: String},
        remark2: {type: String},
        taluka: {type: String},
        mauja: {type: String},
        khataNo: {type: String},
        area: {type: String},
        surveyNo: {type: String},
        aadharCard: {type: String, required: true},
        narega: {type: String, required: true},
        casteValidity: {type: String, required: true},
        nonCreamyLayer: {type: String, required: true},
        ewsCert: {type: String, required: true},
        domicile: {type: String, required: true},
        income: {type: String, required: true},
        projectAffected: {type: String, required: true},
        seniorCitizen: {type: String, required: true},
        residance: {type: String, required: true},
        agriculturist: {type: String, required: true},
        landlessLabour: {type: String, required: true},
        smallLandHolder: {type: String, required: true},
        rationCard: {type: String, required: true},
        individualForestRights: {type: String, required: true},
        pmkisan: {type: String, required: true},
        category: {type: String, required: true},
        sanjayGandhiNiradhar: {type: String, required: true},
        shravanBalaSeva: {type: String, required: true},
        ignOldAgePension: {type: String, required: true},
        ignWidowPension: {type: String, required: true},
        ignDisabilityPension: {type: String, required: true},
        nationalFamilyBenefit: {type: String, required: true},
        voterCard: {type: String, required: true},
        agriCropCredit: {type: String, required: true},
        kisanCreditCard: {type: String, required: true},
        characterCert: {type: String, required: true},
        pmAwasYojana: {type: String, required: true},
        ramaiAwasYojana: {type: String, required: true},
        shabriAwasYojana: {type: String, required: true},
        aadimAwasYojana: {type: String, required: true},
        smsy: {type: String, required: true},
        rgsai: {type: String, required: true},
        personalToilet: {type: String, required: true},
        pmksy: {type: String, required: true},
        mksy: {type: String, required: true},
        soilHealthCard: {type: String, required: true},
        pmfby: {type: String, required: true},
        gmavy: {type: String, required: true},
        mjpjay: {type: String, required: true},
        ayushmanBharath: {type: String, required: true},
        disabilityCert: {type: String, required: true},
        pmJanDhan: {type: String, required: true},
        pmSurakshaBima: {type: String, required: true},
        pmJeevanJyotiBima: {type: String, required: true},
        atalPensionYojana: {type: String, required: true},
        smyGasCyllinder: {type: String, required: true},
        smySolarFence: {type: String, required: true},
        opPhone: {type: String, required: true},
        finalRemarks: {type: String},
        dummy: {type: String},
        dummy2: {type: String},
    },
    { collection: 'offlineData' }
);

const surveyUsersSchema = new Schema(
    {
        taluka: {
            type: String,
            required: 'Name cannot be blank'
        },
        fullName: {
            type: String,
            required: 'Name cannot be blank'
        },
        adharNumber: {
            type: String,
            required: 'AdharNumber  cannot be blank'
        },
        phoneNumber: {
            type: String,
            required: 'phoneNumber  cannot be blank'
        },
        verified: {
            type: Number,
            required: 'Status  cannot be blank'
        },
        urbanRural: {
            type: String,
        },
        villages: []
    },
    { collection: 'surveyusers' }
);

adminSchema.pre("save", async function(next) {
    // Hash the password before saving the user model
    const user = this;
    if (user.isModified("password")) {
        user.password = await bcrypt.hash(user.password, 8);
    }
    next();
});

//this function generates an auth token for the user
adminSchema.methods.generateAuthToken = async function() {

    const user = this;
    const token = jwt.sign(
        { _id: user._id, taluka:user.taluka,username: user.username },
        "legitdocSecretkeyDlt"
    );
    user.token = token;
    await user.save();
    return token;
};

adminSchema.methods.generateUpdateToken = async function() {

    const user = this;
    const token = jwt.sign(
        { _id: user._id, taluka:user.taluka,username: user.username },
        "legitdocSecretkeyDlt"
    );
    user.token = token;
    return token;
};

module.exports = mongoose.model('dataEntry', adminSchema);
module.exports = mongoose.model('citizen', citizenDataSchema);
module.exports = mongoose.model('surveyusers', surveyUsersSchema);
module.exports = mongoose.model('offlineData', offlineDataSchema);