const mongoose = require('mongoose');
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const dataOperator = mongoose.model('dataEntry')
const citizen = mongoose.model('citizen');
const surveyusers = mongoose.model('surveyusers');
const offlineData = mongoose.model('offlineData');


exports.create_offline_entry = (req, res) => {
  const newData = new offlineData(req.body);
  newData.save((err, newData) => {
    if (err) res.send(err);
    res.status(201).json(newData);
  });
};

exports.search_Citizen = (req, res) => {

    var query = { };
    query.adharNumber = req.params.id
    console.log(req.params.id)

    citizen.find(query).select('id fullName category adharNumber village uploaded surveyorId reverted date')
        .exec(function(err, citizen) {
          if (err) res.send(err);
          res.json(citizen);
        });
};

exports.search_Citizen_By_Name = (req, res) => {
   var query = { };
   query.fullName = req.params.id
   console.log(req.params.id)

    citizen.find(query).select('id fullName category adharNumber village uploaded surveyorId reverted date')
        .exec(function(err, citizen) {
          if (err) res.send(err);
          res.json(citizen);
        });
};

exports.search_Citizen_By_SurveyorId = (req, res) => {
  console.log(req.params.id)
  var query = { };

  query.surveyorId = req.params.id
    citizen.find(query).select('id fullName category adharNumber village uploaded surveyorId reverted date')
        .exec(function(err, citizen) {
          if (err) res.send(err);
          res.json(citizen);
        });
};

exports.read_a_citizen = (req, res) => {
  if(req.params.citizenId != null){
    citizen.findById(req.params.citizenId, (err, citizen) => {
      if (err) res.send(err);
      res.json(citizen);
    });
  }
};


exports.update_a_citizenProfile = (req, res) => {
  const update = {
    "$set": {
      "familyId": req.body.fullName,
      "fullName": req.body.fullName,
      "fathersName": req.body.fathersName,
      "mothersName": req.body.mothersName,
      "gender": req.body.gender,
      "maritalStatus": req.body.maritalStatus,
      "motherTongue": req.body.motherTongue,
      "pHandicap": req.body.pHandicap,
      "religion": req.body.religion,
      "category": req.body.category,
      "caste": req.body.caste,
      "education": req.body.education,
      "occupation": req.body.occupation,
      "accountNumber": req.body.accountNumber,
      "ifscCode": req.body.ifscCode,
      "bankName": req.body.bankName,
      "rationCardNumber": req.body.rationCardNumber,
      "incomeLevel": req.body.incomeLevel,
      "phoneNumber": req.body.phoneNumber,
      "houseType": req.body.houseType,
      "houseStatus": req.body.houseStatus,
      "addressDetails": req.body.addressDetails,
      "taluka": req.body.taluka,
      "village": req.body.village,
      "pincode": req.body.pincode,
      "deadOrAlive": req.body.deadOrAlive,
      "dateOfDeath": req.body.dateOfDeath
    }
  };

  citizen.findOneAndUpdate(
      { _id: req.body._id },
      update,
      { new: false },
      (err, citizen) => {
        if (err) res.send(err);
        res.status(201).json(citizen);
      }
  );
};

exports.read_a_surveyor = (req, res) => {
  surveyusers.findById(req.params.id, (err, surveyors) => {
    if (err) res.send(err);
    res.json(surveyors);
  });
};

exports.read_all_surveyusers = (req, res) => {
  surveyusers.find({'taluka':req.params.userId}, (err, surveyusers) => {
    if (err) res.send(err);
    res.json(surveyusers);
  });
};



exports.read_a_subAdmin = (req, res) => {
  dataOperator.findById(req.params.subAdminId, (err, subAdmin) => {
    if (err) res.send(err);
    res.json(subAdmin);
  });
};



exports.registerNewUser = async (req, res) => {
  try {
    let isUser = await dataOperator.find({ username: req.body.username });
    if (isUser.length >= 1) {
      return res.status(409).json({
        message: "username already in use"
      });
    }
    const user = new dataOperator({
      uniqueCode: req.body.uniqueCode,
      taluka: req.body.taluka,
      urbanRural: req.body.urbanRural,
      post: req.body.post,
      department: req.body.department,
      username: req.body.username,
      password: req.body.password,
      type: req.body.type,
      token:' '
    });

    let data = await user.save();
    const token = await user.generateAuthToken();
    res.status(201).json({ data, token });
  } catch (err) {
    console.log(err);
    res.status(400).json({ err: err });
  }
};

//this method search for a user by email and password.
findByCredentials = async (username, password) => {

  const user = await dataOperator.findOne({ username });
  console.log(username)
  if (!user) {
    throw new Error({ error: "Invalid login details" });
  }
  const isPasswordMatch = await bcrypt.compare(password, user.password);
  if (!isPasswordMatch) {
    throw new Error({ error: "Invalid login details" });
  }
  return user;
};

exports.loginUser = async (req, res) => {
  try {
    const username = req.body.username;
    const password = req.body.password;
    const user = await findByCredentials(username, password);
    if (!user) {
      return res
          .status(401)
          .json({ error: "Login failed! Check authentication credentials" });
    }
    const token = await user.generateAuthToken();
    res.status(201).json({ user, token });
  } catch (err) {
    res.status(400).json({ err: err });
  }
};

exports.getUserDetails = async (req, res) => {
  await res.json(req.userData);
};

